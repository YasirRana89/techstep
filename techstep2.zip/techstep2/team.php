<?php include_once("header.php") ?>
<?php require_once('config.php') ?>
<?php require_once( 'db-functtions.php') ?>
<?php $teams = getTeams(); ?>
<div class="team py-5">
		<div class="container py-sm-3">
		<h3 class="heading text-capitalize mb-lg-5 mb-4" style="margin-top :-30px"> Team - <span>Professional teachers</span> </h3>
			<div class="row agile-team-grids">
            <?php foreach ($teams as $teams): ?>
				<div class="col-lg-4 col-sm-6 team-grid">
					<div class="team-img">
						<img src="<?php echo $teams['image']; ?>" class="img-responsive" alt=" " />
						<div class="overlay">
							<h5><?php echo $teams['social_heading']; ?></h5>
							
							<div class="w3l-social">
								<ul>
									<li><a href="<?php echo $teams['link_fb']; ?>"><i class="fab fa-facebook-f"></i></a></li>
									<li><a href="<?php echo $teams['link_twit']; ?>"><i class="fab fa-twitter"></i></a></li>
									<li><a href="<?php echo $teams['link_rss']; ?>"><i class="fa fa-rss"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
					<h4><?php echo $teams['Name']; ?></h4>
					<span><?php echo $teams['Designation']; ?></span>
				</div>
                <div class="clearfix"></div>
                <?php endforeach ?>
			</div>
		</div>
	</div>
    <?php include_once("footer.php") ?>