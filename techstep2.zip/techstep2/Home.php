
<?php 
include("header.php"); 
?>
<?php
include('slider.php');
?>
<?php
include('services.php');
//Written By Ahmad Raza
//PHP Laravel Developer
?>


<!-- courses -->

<!-- teachers -->
<!-- team -->
<?php
include('team.php');?>
	<!-- //team -->
<!-- Section: Testimonials v.4 -->
<?php
include('testimonials.php');?>
<!-- Section: Testimonials v.4 -->
<!-- //teachers -->
<?php include_once("footer.php") ?>