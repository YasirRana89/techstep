
 
<!DOCTYPE html>
<html lang="en">
<head>
<title>TECHSTEP</title>
    
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Eduversity Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
    Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
    
    <!--// Meta tag Keywords -->
    
    <!-- css files -->
    <link rel="stylesheet" href="css/bootstrap.css"> <!-- Bootstrap-Core-CSS -->
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" /> <!-- Style-CSS --> 
    <link rel="stylesheet" href="css/fontawesome-all.css"> <!-- Font-Awesome-Icons-CSS -->
    <!-- //css files -->
    
    <link rel="stylesheet" href="css/jquery.countdown.css" />

    <!--web font-->
    <link href="//fonts.googleapis.com/css?family=PT+Sans+Caption:400,700&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
    <!--//web font-->
    <script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script> <!-- Necessary-JavaScript-File-For-Bootstrap --> 
    <!-- //js -->   
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
  <script src="carouseltest.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
<style>

@media (min-width: 768px){
.nbar {
    border-radius: 0px!important;
    border:none;
}}
.nbar {
    position: relative;
    min-height: 70px!important;
     margin-bottom: 0px; 
    border: 1px solid transparent;
}
.sslider{
  margin-top: -20px;
}
.nnavbar{
  margin-left: 396px!important;
  margin-top: 5px!important;
}
.nnitem{
  margin-left:3px!important;
}
.testimonial{
    padding: 20px 20px 20px 90px;
    margin: 10px 20px 50px 55px;
    border-left: 2px solid #ae483a;
    position: relative;
}
.testimonial:after{
    content: "";
    border-bottom: 25px solid #ae483a;
    border-left: 25px solid transparent;
    border-right: 25px solid transparent;
    position: absolute;
    bottom: -24px;
    left: -26px;
}
.testimonial .pic{
    width: 100px;
    height: 100px;
    border-radius: 50%;
    border: 2px solid #ae483a;
    overflow: hidden;
    position: absolute;
    top: 0;
    left: -50px;
}
.testimonial .pic img{
    width: 100%;
    height: auto;
}
.testimonial .title{
    font-size: 22px;
    font-weight: 600;
    color: #71334a;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin: 0 0 7px 0;
}
.testimonial .post{
    display: block;
    font-size: 15px;
    color: #ae483a;
    text-transform: capitalize;
}
.testimonial .description{
    font-size: 15px;
    color: #ab9c99;
    line-height: 28px;
}
.owl-theme .owl-controls{ margin-top: 10px; }
.owl-theme .owl-controls .owl-page span{
    width: 35px;
    height: 15px;
    border-radius: 0;
    background: #71334a;
    opacity: 0.8;
    transition: all 0.3s ease 0s;
}
.owl-theme .owl-controls .owl-page.active span{
    width: 15px;
    height: 15px;
    border-radius: 50%;
    background: #ae483a;
}
@media only screen and (max-width: 479px){
    .testimonial{
        padding: 20px 0 20px 60px;
        margin: 10px 20px 50px 50px;
    }
    .testimonial .title{ font-size: 20px; }
}

</style>
</head>

<body>

<nav class="navbar nbar navbar-expand-md bg-dark navbar-dark fixed-top">
  <a class="navbar-brand" href="#"><img src="images/logo2.png" style="height:40px; width:170px; margin-top: -10px;" ></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav nnavbar">
      <li class="nav-item nnitem">
      <a class="nav-link" href="Home.php" >Home</a>
      </li>
      <li class="nav-item nnitem">
      <a class="nav-link" href="team.php" >Our Team & Staff</a>
      </li>
      <li class="nav-item nnitem">
      <a class="nav-link" href="softwarehouse.php" >Software House</a>
      </li> 
      <li class="nav-item nnitem">
      <a class="nav-link" href="trainingcenter.php" >Training Center</a>
      </li>  
      <li class="nav-item nnitem">
      <a class="nav-link" href="contact.php" >Contact Us</a>
      </li>  
      <li class="nav-item nnitem">
      <a class="nav-link" href="About.php" >About Us</a>
      </li>     
    </ul>
  </div>  
</nav>