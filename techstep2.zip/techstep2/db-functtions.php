<?php
function getServices() {
	// use global $conn object in function
	global $conn;
	$sql = "SELECT * FROM services";
	$result = mysqli_query($conn, $sql);
	// fetch all posts as an associative array called $posts
	$services = mysqli_fetch_all($result, MYSQLI_ASSOC);

	$final_services = array();
	foreach ($services as $service) {
		array_push($final_services, $service);
	}
	return $final_services;
}

function getTeams() {
	// use global $conn object in function
	global $conn;
	$sql = "SELECT * FROM teams";
	$result = mysqli_query($conn, $sql);
	// fetch all posts as an associative array called $posts
	$teams = mysqli_fetch_all($result, MYSQLI_ASSOC);

	$final_teams = array();
	foreach ($teams as $team) {
		array_push($final_teams, $team);
	}
	return $final_teams;
}
?>