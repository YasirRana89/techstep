<?php require_once('config.php') ?>
<?php require_once( 'db-functtions.php') ?>
<?php $services = getServices(); ?>

            <section class="courses py-5">
                    <div class="container py-sm-3">
                        <h3 class="heading text-capitalize mb-lg-5 mb-4"> Services - <span>What We Offer</span> </h3>
                        
                        <div class="row course-grids">
                        <?php foreach ($services as $service): ?>
                            <div class="col-lg-4 col-md-6">
                                <div class="card">
                                  <center><img class="card-img-top" src="<?php echo $service['image']; ?>" alt="Card image cap" style="width:200px;height: 200px"></center>
                                  <div class="card-body">
                                    <center><h5 class="card-title"><?php echo $service['heading']; ?></h5>
                                    <p class="card-text mb-3"><?php echo $service['description']; ?></p></center>
                                    <center><a href="contact.html" class="btn btn-primary"><i class="fas fa-graduation-cap"></i> Join Course</a></center>
                                  </div>
                                </div>
                            </div>
                            <?php endforeach ?>
                        </div>
                        
                    </div>
                </section>

