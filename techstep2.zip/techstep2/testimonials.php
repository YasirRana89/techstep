<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div id="testimonial-slider" class="owl-carousel">
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/img-1.jpg">
                    </div>
                    <h3 class="title">Williamson</h3>
                    <span class="post">Web Developer</span>
                    <p class="description">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras suscipit arcu sed scelerisque auctor. Vestibulum justo enim, dapibus sed magna sed, consequat accumsan nunc. Vivamus.
                    </p>
                </div>
 
                <div class="testimonial">
                    <div class="pic">
                        <img src="images/img-2.jpg">
                    </div>
                    <h3 class="title">Kristina</h3>
                    <span class="post">Web Designer</span>
                    <p class="description">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras suscipit arcu sed scelerisque auctor. Vestibulum justo enim, dapibus sed magna sed, consequat accumsan nunc. Vivamus.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>